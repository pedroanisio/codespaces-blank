# Half-Mirror Figure Pipeline

Extract the right half of a frontal line-art figure via OpenCV,
then reconstruct the full symmetric body by mirroring — using
only matplotlib and a JSON file.

## Files

### Scripts
- `extract_contours.py` — **Stage 1** (needs OpenCV, scipy, skimage)
  Reads an image, extracts contour + detail strokes + measurements,
  saves as JSON.
- `draw_figure.py` — **Stage 2** (needs only matplotlib + numpy)
  Reads a JSON, draws the full mirrored figure as PNG.

### Usage
```bash
# One-time extraction (needs OpenCV)
python extract_contours.py input.jpg output.json

# Draw anywhere (no OpenCV needed)
python draw_figure.py output.json output.png
```

### Extracted Figures

| Figure | JSON | PNG | Coordinates | Contour pts | Strokes |
|--------|------|-----|-------------|-------------|---------|
| Tactical Operator | `tactical_operator.json` | `tactical_operator.png` | `tactical_operator_full_data.txt` | 788 | 148 |
| Motorcycle Rider | `moto_rider.json` | `moto_rider.png` | `moto_rider_full_data.txt` | 734 | 292 |
| Anatomy Study | `anatomy_study.json` | `anatomy_study.png` | `anatomy_study_full_data.txt` | 699 | 81 |
| Hero Figure | `hero_figure.json` | `hero_figure.png` | `hero_figure_full_data.txt` | 640 | 118 |
| Biker Girl | `biker_girl.json` | `biker_girl.png` | `biker_girl_full_data.txt` | 639 | 179 |

### Coordinate System
- `dx` = distance from midline in head-units (positive = body's right)
- `dy` = distance from crown in head-units (0 = top of head, 8 = sole)
- Mirror = negate dx

### JSON Structure
```
{
  "meta":         { source, image_size, midline_px, scale, ... },
  "symmetry":     { "1.0": { right_dx, left_dx, delta }, ... },
  "contour":      [[dx, dy], ...],          // right-half silhouette
  "measurements": { "0.0": [{outer_dx, inner_dx}, ...], ... },
  "strokes":      [[[dx, dy], ...], ...]    // internal detail lines
}
```
