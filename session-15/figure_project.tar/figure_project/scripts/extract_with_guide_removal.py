"""
v4: Tighter guide removal + clamped silhouette.
Fix: use global threshold only for silhouette (no adaptive noise),
     and hard-clamp contour width to bounding box.
"""
import cv2, numpy as np, json
from scipy.ndimage import uniform_filter1d
from skimage.morphology import skeletonize

def extract_v4(img_path, json_path):
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    
    # Clean global threshold only (no adaptive noise)
    _, line_global = cv2.threshold(gray, 215, 255, cv2.THRESH_BINARY_INV)
    
    # Remove horizontal/vertical guides
    horiz_k = cv2.getStructuringElement(cv2.MORPH_RECT, (w // 4, 1))
    vert_k = cv2.getStructuringElement(cv2.MORPH_RECT, (1, h // 4))
    h_guides = cv2.dilate(cv2.morphologyEx(line_global, cv2.MORPH_OPEN, horiz_k), np.ones((7,1), np.uint8), iterations=2)
    v_guides = cv2.dilate(cv2.morphologyEx(line_global, cv2.MORPH_OPEN, vert_k), np.ones((1,7), np.uint8), iterations=2)
    
    line_clean = line_global.copy()
    line_clean[h_guides > 0] = 0
    line_clean[v_guides > 0] = 0
    
    # Bounding box from cleaned lines
    col_s = line_clean.sum(axis=0)
    row_s = line_clean.sum(axis=1)
    fc = np.where(col_s > col_s.max() * 0.03)[0]
    fr = np.where(row_s > row_s.max() * 0.03)[0]
    x_left, x_right = fc[0], fc[-1]
    y_top, y_bot = fr[0], fr[-1]
    midline_px = (x_left + x_right) / 2.0
    fig_height_px = y_bot - y_top
    scale = 8.0 / fig_height_px
    
    # Max plausible dx from bounding box
    max_plausible_dx = (x_right - midline_px) * scale * 1.05
    
    print(f"{img_path.split('/')[-1]}: bbox=[{x_left},{x_right}]x[{y_top},{y_bot}], "
          f"midline={midline_px:.0f}, max_dx_bound={max_plausible_dx:.3f}")
    
    # Scan-line silhouette
    line_thick = cv2.dilate(line_clean, np.ones((3,3), np.uint8), iterations=1)
    right_outer, right_inner = [], []
    
    for row in range(y_top, y_bot + 1):
        ink = np.where(line_thick[row, :] > 0)[0]
        if len(ink) == 0: continue
        dy = (row - y_top) * scale
        right_px = ink[ink >= midline_px]
        if len(right_px) > 0:
            outer_dx = min((right_px[-1] - midline_px) * scale, max_plausible_dx)
            inner_dx = (right_px[0] - midline_px) * scale
            right_outer.append([outer_dx, dy])
            if outer_dx - inner_dx > 0.05:
                right_inner.append([inner_dx, dy])
    
    right_outer = np.array(right_outer)
    right_inner = np.array(right_inner)
    contour_raw = np.vstack([right_outer, right_inner[::-1]])
    contour_raw[:,0] = np.maximum(contour_raw[:,0], 0)
    
    # Resample + smooth
    diffs = np.diff(contour_raw, axis=0)
    seg_len = np.sqrt(diffs[:,0]**2 + diffs[:,1]**2)
    cum = np.concatenate([[0], np.cumsum(seg_len)])
    t_uniform = np.linspace(0, cum[-1], 700)
    contour_final = np.column_stack([
        uniform_filter1d(np.interp(t_uniform, cum, contour_raw[:,0]), 5, mode='nearest'),
        uniform_filter1d(np.interp(t_uniform, cum, contour_raw[:,1]), 5, mode='nearest'),
    ])
    contour_final[:,0] = np.maximum(contour_final[:,0], 0)
    
    print(f"  Contour: max_dx={contour_final[:,0].max():.3f}")
    
    # Strokes (from guide-cleaned source)
    clean_for_strokes = line_global.copy()
    clean_for_strokes[h_guides > 0] = 0
    
    all_contours, _ = cv2.findContours(clean_for_strokes, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    strokes = []
    contour_max = contour_final[:,0].max()
    
    for cnt in all_contours:
        pts = cnt.squeeze()
        if pts.ndim < 2 or len(pts) < 5: continue
        rm = pts[:,0] >= (midline_px - 3)
        if rm.sum() < 5: continue
        pr = pts[rm].astype(float)
        dx = np.maximum((pr[:,0] - midline_px) * scale, 0)
        dy = (pr[:,1] - y_top) * scale
        if cv2.contourArea(cnt) > 50000: continue
        if dy.min() > 8.2 or dy.max() < -0.2: continue
        stroke = np.column_stack([dx, dy])
        if stroke[:,0].max() > contour_max * 1.15: continue
        if len(stroke) > 60: stroke = stroke[np.linspace(0, len(stroke)-1, 60, dtype=int)]
        strokes.append(stroke)
    
    # Skeleton strokes
    skel = skeletonize(clean_for_strokes > 0).astype(np.uint8) * 255
    om = np.zeros_like(clean_for_strokes)
    cv2.drawContours(om, [max(all_contours, key=cv2.contourArea)], 0, 255, 5)
    inner_skel = skel.copy(); inner_skel[om > 0] = 0
    
    n_labels, labels = cv2.connectedComponents(inner_skel)
    for lid in range(1, n_labels):
        ys, xs = np.where(labels == lid)
        right = xs >= (midline_px - 3)
        if right.sum() < 8: continue
        dx = np.maximum((xs[right].astype(float) - midline_px) * scale, 0)
        dy = (ys[right].astype(float) - y_top) * scale
        if dy.min() > 8.2: continue
        if dx.max() > contour_max * 1.15: continue
        pts = list(zip(dx, dy))
        start = min(range(len(pts)), key=lambda i: pts[i][1])
        ordered = [pts[start]]
        remaining = set(range(len(pts))) - {start}
        for _ in range(min(len(pts)-1, 200)):
            if not remaining: break
            last = ordered[-1]
            bd, bi = float('inf'), None
            for i in remaining:
                d = (pts[i][0]-last[0])**2 + (pts[i][1]-last[1])**2
                if d < bd: bd, bi = d, i
            if bi is None or bd > 0.1**2: break
            ordered.append(pts[bi]); remaining.discard(bi)
        if len(ordered) < 5: continue
        stroke = np.array(ordered)
        if len(stroke) > 60: stroke = stroke[np.linspace(0, len(stroke)-1, 60, dtype=int)]
        strokes.append(stroke)
    
    print(f"  Strokes: {len(strokes)}, pts: {sum(len(s) for s in strokes)}")
    
    data = {
        "contour": contour_final.tolist(),
        "strokes": [s.tolist() for s in strokes],
        "meta": {
            "contour_points": len(contour_final), "detail_strokes": len(strokes),
            "source": img_path.split("/")[-1],
            "image_size": [w, h], "midline_px": float(midline_px),
            "y_top_px": int(y_top), "y_bot_px": int(y_bot),
            "fig_height_px": int(fig_height_px), "scale_px_to_hu": float(scale),
        }
    }
    with open(json_path, "w") as f:
        json.dump(data, f)
    return data

extract_v4("/mnt/user-data/uploads/13406.jpg", "/home/claude/heroine_front.json")
extract_v4("/mnt/user-data/uploads/13408.jpg", "/home/claude/heroine_back.json")
