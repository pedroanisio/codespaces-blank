"""
Batch extract from multiple images using the v3 pipeline.
"""
import cv2, numpy as np, json
from scipy.ndimage import uniform_filter1d
from skimage.morphology import skeletonize

def extract(img_path, json_path):
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    
    # Line detection
    line_bin = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                      cv2.THRESH_BINARY_INV, 15, 8)
    _, line_global = cv2.threshold(gray, 210, 255, cv2.THRESH_BINARY_INV)
    line_combined = cv2.bitwise_or(line_bin, line_global)
    
    # Bounding box
    col_sums = line_combined.sum(axis=0)
    row_sums = line_combined.sum(axis=1)
    fig_cols = np.where(col_sums > col_sums.max() * 0.01)[0]
    fig_rows = np.where(row_sums > row_sums.max() * 0.01)[0]
    x_left, x_right = fig_cols[0], fig_cols[-1]
    y_top, y_bot = fig_rows[0], fig_rows[-1]
    midline_px = (x_left + x_right) / 2.0
    fig_height_px = y_bot - y_top
    scale = 8.0 / fig_height_px
    
    # Scan-line silhouette
    line_thick = cv2.dilate(line_combined, np.ones((3,3), np.uint8), iterations=1)
    right_outer, right_inner = [], []
    
    for row in range(y_top, y_bot + 1):
        ink = np.where(line_thick[row, :] > 0)[0]
        if len(ink) == 0: continue
        dy = (row - y_top) * scale
        right_px = ink[ink >= midline_px]
        if len(right_px) > 0:
            outer_dx = (right_px[-1] - midline_px) * scale
            inner_dx = (right_px[0] - midline_px) * scale
            right_outer.append([outer_dx, dy])
            if outer_dx - inner_dx > 0.05:
                right_inner.append([inner_dx, dy])
    
    right_outer = np.array(right_outer)
    right_inner = np.array(right_inner)
    contour_raw = np.vstack([right_outer, right_inner[::-1]])
    contour_raw[:,0] = np.maximum(contour_raw[:,0], 0)
    
    # Resample
    diffs = np.diff(contour_raw, axis=0)
    seg_len = np.sqrt(diffs[:,0]**2 + diffs[:,1]**2)
    cum = np.concatenate([[0], np.cumsum(seg_len)])
    t_uniform = np.linspace(0, cum[-1], 700)
    contour_final = np.column_stack([
        np.interp(t_uniform, cum, contour_raw[:,0]),
        np.interp(t_uniform, cum, contour_raw[:,1]),
    ])
    contour_final = np.column_stack([
        uniform_filter1d(contour_final[:,0], 5, mode='nearest'),
        uniform_filter1d(contour_final[:,1], 5, mode='nearest'),
    ])
    contour_final[:,0] = np.maximum(contour_final[:,0], 0)
    
    # Strokes: contour-based
    _, clean_lines = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
    all_contours, _ = cv2.findContours(clean_lines, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    
    strokes = []
    for cnt in all_contours:
        pts = cnt.squeeze()
        if pts.ndim < 2 or len(pts) < 5: continue
        right_mask = pts[:,0] >= (midline_px - 3)
        if right_mask.sum() < 5: continue
        pts_r = pts[right_mask].astype(float)
        dx = np.maximum((pts_r[:,0] - midline_px) * scale, 0)
        dy = (pts_r[:,1] - y_top) * scale
        if cv2.contourArea(cnt) > 50000: continue
        if dy.min() > 8.2 or dy.max() < -0.2: continue
        stroke = np.column_stack([dx, dy])
        if len(stroke) > 60:
            stroke = stroke[np.linspace(0, len(stroke)-1, 60, dtype=int)]
        strokes.append(stroke)
    
    # Strokes: skeleton-based
    skel = skeletonize(clean_lines > 0).astype(np.uint8) * 255
    outer_mask = np.zeros_like(clean_lines)
    largest = max(all_contours, key=cv2.contourArea)
    cv2.drawContours(outer_mask, [largest], 0, 255, 5)
    inner_skel = skel.copy()
    inner_skel[outer_mask > 0] = 0
    
    n_labels, labels = cv2.connectedComponents(inner_skel)
    for lid in range(1, n_labels):
        ys, xs = np.where(labels == lid)
        right = xs >= (midline_px - 3)
        if right.sum() < 8: continue
        dx = np.maximum((xs[right].astype(float) - midline_px) * scale, 0)
        dy = (ys[right].astype(float) - y_top) * scale
        if dy.min() > 8.2: continue
        
        pts = list(zip(dx, dy))
        start = min(range(len(pts)), key=lambda i: pts[i][1])
        ordered = [pts[start]]
        remaining = set(range(len(pts))) - {start}
        for _ in range(min(len(pts)-1, 200)):
            if not remaining: break
            last = ordered[-1]
            best_d, best_i = float('inf'), None
            for i in remaining:
                d = (pts[i][0]-last[0])**2 + (pts[i][1]-last[1])**2
                if d < best_d: best_d, best_i = d, i
            if best_i is None or best_d > 0.1**2: break
            ordered.append(pts[best_i])
            remaining.discard(best_i)
        if len(ordered) < 5: continue
        stroke = np.array(ordered)
        if len(stroke) > 60:
            stroke = stroke[np.linspace(0, len(stroke)-1, 60, dtype=int)]
        strokes.append(stroke)
    
    data = {
        "contour": contour_final.tolist(),
        "strokes": [s.tolist() for s in strokes],
        "meta": {
            "contour_points": len(contour_final),
            "detail_strokes": len(strokes),
            "source": img_path.split("/")[-1],
            "image_size": [w, h],
            "midline_px": float(midline_px),
            "y_top_px": int(y_top), "y_bot_px": int(y_bot),
            "fig_height_px": int(fig_height_px),
            "scale_px_to_hu": float(scale),
        }
    }
    with open(json_path, "w") as f:
        json.dump(data, f)
    
    src = img_path.split("/")[-1]
    print(f"{src}: {len(contour_final)} contour, {len(strokes)} strokes, {sum(len(s) for s in strokes)} pts")
    return data

# Extract both
front = extract("/mnt/user-data/uploads/13406.jpg", "/home/claude/heroine_front.json")
back = extract("/mnt/user-data/uploads/13408.jpg", "/home/claude/heroine_back.json")
