"""
v3: Tighter silhouette + better stroke extraction.

Fixes:
  - Use adaptive threshold instead of global for line detection
  - Thinner morphological closing for the silhouette
  - Use contour hierarchy to find internal detail contours
  - Better stroke path tracing
"""

import cv2
import numpy as np
import json
from scipy.ndimage import uniform_filter1d
from skimage.morphology import skeletonize

img = cv2.imread("/mnt/user-data/uploads/13404.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
h, w = gray.shape

# ─── LINE DETECTION ───
# Adaptive threshold captures thin lines better
line_bin = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                  cv2.THRESH_BINARY_INV, 15, 8)
# Also a global threshold for broader strokes
_, line_global = cv2.threshold(gray, 210, 255, cv2.THRESH_BINARY_INV)
# Combine
line_combined = cv2.bitwise_or(line_bin, line_global)

# ─── SILHOUETTE: scan-line approach ───
# For each row, find leftmost and rightmost ink pixel
# This gives a clean width profile without flood-fill artifacts

# First find figure bounding box
col_sums = line_combined.sum(axis=0)
row_sums = line_combined.sum(axis=1)
col_thresh = col_sums.max() * 0.01
row_thresh = row_sums.max() * 0.01

fig_cols = np.where(col_sums > col_thresh)[0]
fig_rows = np.where(row_sums > row_thresh)[0]
x_left, x_right = fig_cols[0], fig_cols[-1]
y_top, y_bot = fig_rows[0], fig_rows[-1]
midline_px = (x_left + x_right) / 2.0
fig_height_px = y_bot - y_top
scale = 8.0 / fig_height_px

print(f"Bounds: x=[{x_left},{x_right}], y=[{y_top},{y_bot}]")
print(f"Midline: {midline_px:.1f}, Height: {fig_height_px}px, Scale: {scale:.6f}")

# Build right-side width profile by scanning each row
# For the right half: at each y, find the rightmost ink pixel (outer contour)
# and also track the inner boundary

# Dilate lines slightly to connect near-gaps
line_thick = cv2.dilate(line_combined, np.ones((3,3), np.uint8), iterations=1)

right_outer = []  # (dx, dy) going down the right outer edge
right_inner = []  # (dx, dy) going up the right inner edge (near midline)

for row in range(y_top, y_bot + 1):
    scanline = line_thick[row, :]
    ink_pixels = np.where(scanline > 0)[0]
    
    if len(ink_pixels) == 0:
        continue
    
    dy = (row - y_top) * scale
    
    # Right half: pixels to the right of midline
    right_pixels = ink_pixels[ink_pixels >= midline_px]
    if len(right_pixels) > 0:
        # Outer = rightmost ink pixel
        outer_x = right_pixels[-1]
        outer_dx = (outer_x - midline_px) * scale
        right_outer.append([outer_dx, dy])
        
        # Inner = leftmost right-side ink pixel (but skip midline noise)
        # Look for the first ink pixel after a gap from midline
        inner_x = right_pixels[0]
        inner_dx = (inner_x - midline_px) * scale
        # Only add if it's meaningfully different from outer
        if outer_dx - inner_dx > 0.05:
            right_inner.append([inner_dx, dy])

right_outer = np.array(right_outer)
right_inner = np.array(right_inner)

print(f"Scan-line profile: {len(right_outer)} outer, {len(right_inner)} inner pts")

# Build contour: down the outer edge, up the inner edge
return_path = right_inner[::-1]  # reverse for going back up

# For the head region (dy < 1.0), there's no arm separation,
# so inner path should be near midline
head_return = np.array([[0.01, dy] for dy in np.linspace(1.0, 0.0, 50)])

# Combine paths
contour_raw = np.vstack([right_outer, return_path])

# Clamp
contour_raw[:,0] = np.maximum(contour_raw[:,0], 0)

# Resample
diffs = np.diff(contour_raw, axis=0)
seg_len = np.sqrt(diffs[:,0]**2 + diffs[:,1]**2)
cum = np.concatenate([[0], np.cumsum(seg_len)])
total_len = cum[-1]

n_target = 700
t_uniform = np.linspace(0, total_len, n_target)
contour_final = np.column_stack([
    np.interp(t_uniform, cum, contour_raw[:,0]),
    np.interp(t_uniform, cum, contour_raw[:,1]),
])

# Smooth
contour_final = np.column_stack([
    uniform_filter1d(contour_final[:,0], 5, mode='nearest'),
    uniform_filter1d(contour_final[:,1], 5, mode='nearest'),
])
contour_final[:,0] = np.maximum(contour_final[:,0], 0)

print(f"Contour: {len(contour_final)} pts")
print(f"  dx: [{contour_final[:,0].min():.4f}, {contour_final[:,0].max():.4f}]")
print(f"  dy: [{contour_final[:,1].min():.4f}, {contour_final[:,1].max():.4f}]")

# ─── STROKES: use ALL contours from the original line art ───
# Find contours in the original clean line art
_, clean_lines = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
all_contours, hierarchy = cv2.findContours(clean_lines, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

print(f"\nAll contours found: {len(all_contours)}")

strokes = []
for cnt in all_contours:
    pts = cnt.squeeze()
    if pts.ndim < 2 or len(pts) < 5:
        continue
    
    # Only right-half points
    right_mask = pts[:,0] >= (midline_px - 3)
    if right_mask.sum() < 5:
        continue
    
    pts_r = pts[right_mask].astype(float)
    
    # Convert to head-units
    dx = (pts_r[:,0] - midline_px) * scale
    dy = (pts_r[:,1] - y_top) * scale
    dx = np.maximum(dx, 0)
    
    # Skip if it's too close to the outer contour (it's the silhouette itself)
    # Check: is this contour the largest one or very close to the bounding box?
    area = cv2.contourArea(cnt)
    if area > 50000:  # skip the outer silhouette
        continue
    
    # Skip strokes entirely outside figure bounds
    if dy.min() > 8.2 or dy.max() < -0.2:
        continue
    
    stroke = np.column_stack([dx, dy])
    
    # Subsample
    if len(stroke) > 60:
        idx = np.linspace(0, len(stroke)-1, 60, dtype=int)
        stroke = stroke[idx]
    
    strokes.append(stroke)

# Also extract from skeleton for lines that aren't closed contours
skel = skeletonize(clean_lines > 0).astype(np.uint8) * 255
# Remove outer edge
outer_mask = np.zeros_like(clean_lines)
# Use the largest contour as outer mask
largest_cnt = max(all_contours, key=cv2.contourArea)
cv2.drawContours(outer_mask, [largest_cnt], 0, 255, 5)

inner_skel = skel.copy()
inner_skel[outer_mask > 0] = 0

n_labels, labels = cv2.connectedComponents(inner_skel)
for label_id in range(1, n_labels):
    ys, xs = np.where(labels == label_id)
    right = xs >= (midline_px - 3)
    if right.sum() < 8:
        continue
    
    xs_r, ys_r = xs[right].astype(float), ys[right].astype(float)
    dx = np.maximum((xs_r - midline_px) * scale, 0)
    dy = (ys_r - y_top) * scale
    
    if dy.min() > 8.2:
        continue
    
    # Path-trace
    pts = list(zip(dx, dy))
    start = min(range(len(pts)), key=lambda i: pts[i][1])
    ordered = [pts[start]]
    remaining = set(range(len(pts))) - {start}
    
    for _ in range(min(len(pts)-1, 200)):
        if not remaining:
            break
        last = ordered[-1]
        best_d, best_i = float('inf'), None
        for i in remaining:
            d = (pts[i][0]-last[0])**2 + (pts[i][1]-last[1])**2
            if d < best_d:
                best_d, best_i = d, i
        if best_i is None or best_d > 0.1**2:
            break
        ordered.append(pts[best_i])
        remaining.discard(best_i)
    
    if len(ordered) < 5:
        continue
    
    stroke = np.array(ordered)
    if len(stroke) > 60:
        idx = np.linspace(0, len(stroke)-1, 60, dtype=int)
        stroke = stroke[idx]
    
    strokes.append(stroke)

print(f"Total strokes: {len(strokes)}, pts: {sum(len(s) for s in strokes)}")

# ─── SAVE ───
data = {
    "contour": contour_final.tolist(),
    "strokes": [s.tolist() for s in strokes],
    "meta": {
        "contour_points": len(contour_final),
        "detail_strokes": len(strokes),
        "source": "13404.jpg",
        "image_size": [w, h],
        "midline_px": float(midline_px),
        "y_top_px": int(y_top),
        "y_bot_px": int(y_bot),
        "fig_height_px": int(fig_height_px),
        "scale_px_to_hu": float(scale),
    }
}

with open("/home/claude/warrior.json", "w") as f:
    json.dump(data, f)
print("Saved warrior.json")

