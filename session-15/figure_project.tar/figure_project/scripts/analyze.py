import json
import numpy as np
from scipy.signal import argrelextrema
from scipy.ndimage import uniform_filter1d

def load(p):
    with open(p) as f: return json.load(f)

biker = load("/home/claude/biker_girl.json")
moto  = load("/home/claude/moto_rider.json")
anat  = load("/mnt/user-data/uploads/anatomy_study.json")
hero  = load("/home/claude/hero_figure.json")

def profile(name, data):
    c = np.array(data["contour"])
    strokes = [np.array(s) for s in data["strokes"]]
    
    # Basics
    diffs = np.diff(c, axis=0)
    steps = np.sqrt(diffs[:,0]**2 + diffs[:,1]**2)
    gap = np.linalg.norm(c[0] - c[-1])
    
    # Stroke stats
    lengths = [len(s) for s in strokes]
    all_pts = np.vstack(strokes) if strokes else np.zeros((0,2))
    
    # Palindromes
    pals = 0
    for s in strokes:
        n = len(s)
        if n >= 6:
            mid = n // 2
            first, second = s[:mid], s[n-mid:][::-1]
            if len(first) == len(second) and np.abs(first - second).max() < 0.025:
                pals += 1
    
    # Dups
    dups = sum(sum(1 for j in range(1, len(s)) if np.allclose(s[j], s[j-1], atol=1e-5)) for s in strokes)
    
    # Width at each head unit
    widths = {}
    for hu in range(9):
        mask = np.abs(c[:,1] - hu) < 0.15
        if mask.any():
            widths[hu] = c[mask, 0].max()
    
    h = c[:,1].max() - c[:,1].min()
    w = c[:,0].max()
    
    return {
        'name': name, 'n_contour': len(c), 'n_strokes': len(strokes),
        'total_stroke_pts': sum(lengths),
        'step_mean': steps.mean(), 'step_cv': steps.std()/steps.mean()*100,
        'gap': gap, 'height': h, 'max_dx': w, 'ratio': h/(2*w),
        'palindromes': pals, 'dup_pts': dups,
        'widths': widths,
        'median_stroke_len': np.median(lengths) if lengths else 0,
        'max_stroke_len': max(lengths) if lengths else 0,
    }

profiles = [
    profile("biker_girl", biker),
    profile("moto_rider", moto),
    profile("anatomy", anat),
    profile("hero", hero),
]

# Print comparison table
print(f"{'':>16} {'biker':>10} {'moto':>10} {'anatomy':>10} {'hero':>10}")
print(f"{'─'*16} {'─'*10} {'─'*10} {'─'*10} {'─'*10}")
for key in ['n_contour', 'n_strokes', 'total_stroke_pts', 'step_cv', 
            'gap', 'height', 'max_dx', 'ratio', 'palindromes', 'dup_pts',
            'median_stroke_len', 'max_stroke_len']:
    vals = [p[key] for p in profiles]
    if key in ('gap', 'step_cv', 'height', 'max_dx', 'ratio'):
        print(f"{key:>16} {vals[0]:>10.4f} {vals[1]:>10.4f} {vals[2]:>10.4f} {vals[3]:>10.4f}")
    else:
        print(f"{key:>16} {vals[0]:>10} {vals[1]:>10} {vals[2]:>10} {vals[3]:>10}")

print(f"\n{'Width profile (max dx at each head-unit):':}")
print(f"{'hu':>4} {'biker':>10} {'moto':>10} {'anatomy':>10} {'hero':>10}")
for hu in range(9):
    vals = [p['widths'].get(hu, 0) for p in profiles]
    print(f"{hu:>4} {vals[0]:>10.4f} {vals[1]:>10.4f} {vals[2]:>10.4f} {vals[3]:>10.4f}")

# Biker-specific observations
print(f"\n{'='*60}")
print(f"  BIKER GIRL — specific analysis")
print(f"{'='*60}")

c = np.array(biker["contour"])
strokes = [np.array(s) for s in biker["strokes"]]

# Stroke density by region
print("\nStroke density by body region:")
regions = [(0,1,'head'), (1,2,'torso_upper'), (2,3,'torso_lower'),
           (3,4,'hip/thigh'), (4,5,'upper_leg'), (5,6,'lower_leg'),
           (6,8,'ankle/foot')]
for ylo, yhi, rname in regions:
    n = sum(1 for s in strokes if ylo <= np.mean(s[:,1]) < yhi)
    pts = sum(len(s) for s in strokes if ylo <= np.mean(s[:,1]) < yhi)
    print(f"  {rname:<14} {n:>3} strokes, {pts:>5} pts")

# Laterality
right_only = sum(1 for s in strokes if s[:,0].min() >= 0.01)
crossing = sum(1 for s in strokes if s[:,0].min() < 0.005 and s[:,0].max() > 0.01)
print(f"\nLaterality: {right_only} right-only, {crossing} crossing midline")

# Negative dx in contour
neg = np.sum(c[:,0] < 0)
print(f"Contour pts with dx < 0: {neg}")

# Compare silhouette to moto rider (both are bikers)
print("\nBiker vs Moto width ratio (same subject type):")
bw = profiles[0]['widths']
mw = profiles[1]['widths']
for hu in range(9):
    if hu in bw and hu in mw and mw[hu] > 0:
        ratio = bw[hu] / mw[hu]
        print(f"  y={hu}: biker/moto = {ratio:.3f} ({'narrower' if ratio < 1 else 'wider'})")

