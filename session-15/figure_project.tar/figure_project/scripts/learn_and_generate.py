"""
Data-driven figure generator.

Strategy:
  1. Normalize all three contours to a common parameterization
  2. Extract the average contour path (not just width — the FULL trace)
  3. Extract stroke density and shape statistics per body region
  4. Generate new figures by sampling/interpolating from these patterns
"""

import json
import numpy as np
from scipy.interpolate import interp1d
from scipy.ndimage import uniform_filter1d
from scipy.signal import argrelextrema

def load(path):
    with open(path) as f:
        return json.load(f)

moto = load("/home/claude/moto_rider.json")
anat = load("/mnt/user-data/uploads/anatomy_study.json")
hero = load("/home/claude/hero_figure.json")

# ═══════════════════════════════════════════════════════════
# STEP 1: Parameterize each contour by normalized arc-length
# ═══════════════════════════════════════════════════════════

def parameterize_contour(c):
    """Convert contour to arc-length parameterization [0, 1]."""
    c = np.array(c)
    diffs = np.diff(c, axis=0)
    seg_len = np.sqrt(diffs[:,0]**2 + diffs[:,1]**2)
    cum = np.concatenate([[0], np.cumsum(seg_len)])
    return cum / cum[-1], c  # (t, points)

def resample_contour(t, c, n=800):
    """Resample contour at n uniform arc-length steps."""
    t_uniform = np.linspace(0, 1, n)
    dx_interp = np.interp(t_uniform, t, c[:,0])
    dy_interp = np.interp(t_uniform, t, c[:,1])
    return np.column_stack([dx_interp, dy_interp])

contours = {}
for name, data in [("moto", moto), ("anat", anat), ("hero", hero)]:
    t, c = parameterize_contour(data["contour"])
    contours[name] = resample_contour(t, c, n=800)

# ═══════════════════════════════════════════════════════════
# STEP 2: Align contours using structural landmarks
#   All three share the same topology:
#   crown(t=0) → head → neck → shoulder → arm → hand →
#   inner arm → armpit → torso → hip → leg → foot →
#   inner leg → crotch → return to crown(t=1)
# ═══════════════════════════════════════════════════════════

# Find key landmarks in each contour using dx extrema
def find_landmarks(c, name):
    """Find structural landmarks in the contour."""
    dx_smooth = uniform_filter1d(c[:,0], 25, mode='nearest')
    
    peaks = argrelextrema(dx_smooth, np.greater, order=20)[0]
    valleys = argrelextrema(dx_smooth, np.less, order=20)[0]
    
    # Sort by index (= position along contour)
    all_extrema = sorted(
        [(p, 'peak', c[p,0], c[p,1]) for p in peaks] +
        [(v, 'valley', c[v,0], c[v,1]) for v in valleys],
        key=lambda x: x[0]
    )
    
    # Identify structural phases based on dy and dx patterns
    # The outer contour (first ~55% of points) traces:
    #   crown → head_peak → neck_valley → shoulder_peak → 
    #   hand/forearm region → armpit_valley → hip_peak →
    #   foot_peak → crotch_valley → return
    
    landmarks = {}
    
    # Head peak: first peak with dy < 1.0
    for idx, typ, dx, dy in all_extrema:
        if typ == 'peak' and dy < 1.5 and dx > 0.2:
            landmarks['head_peak'] = idx
            break
    
    # Neck valley: first valley after head peak
    for idx, typ, dx, dy in all_extrema:
        if typ == 'valley' and idx > landmarks.get('head_peak', 0) and dy < 2.0 and dx < 0.5:
            landmarks['neck_valley'] = idx
            break
    
    # Shoulder/body peak: largest dx peak in first half
    first_half = [(i,t,d,y) for i,t,d,y in all_extrema if i < 400 and t == 'peak']
    if first_half:
        body_peak = max(first_half, key=lambda x: x[2])
        landmarks['body_peak'] = body_peak[0]
    
    # Crotch/midline valley: the valley with smallest dx (closest to midline) in middle section
    mid_valleys = [(i,t,d,y) for i,t,d,y in all_extrema if t == 'valley' and 2.5 < y < 5.0]
    if mid_valleys:
        crotch = min(mid_valleys, key=lambda x: x[2])
        landmarks['inner_valley'] = crotch[0]
    
    return landmarks, all_extrema

for name in ["moto", "anat", "hero"]:
    lm, ext = find_landmarks(contours[name], name)
    print(f"{name}: landmarks at indices {lm}")

# ═══════════════════════════════════════════════════════════
# STEP 3: Compute average contour
#   Since all are resampled to 800 pts with same topology,
#   we can simply average them (with optional weighting)
# ═══════════════════════════════════════════════════════════

# But first: the moto rider has clothing bulk. The anatomy is "true" body.
# The hero has armor. Let's weight anatomy more heavily for a "base human".
# Or better: let's just try averaging all three and see what happens.

avg_contour = np.mean([contours["moto"], contours["anat"], contours["hero"]], axis=0)

# Also compute a weighted average favoring anatomy (the "cleanest" body)
weighted_contour = (
    0.2 * contours["moto"] + 
    0.6 * contours["anat"] + 
    0.2 * contours["hero"]
)

# Smooth lightly
avg_smooth = np.column_stack([
    uniform_filter1d(avg_contour[:,0], 5, mode='nearest'),
    uniform_filter1d(avg_contour[:,1], 5, mode='nearest'),
])
wt_smooth = np.column_stack([
    uniform_filter1d(weighted_contour[:,0], 5, mode='nearest'),
    uniform_filter1d(weighted_contour[:,1], 5, mode='nearest'),
])

# Clamp dx >= 0
avg_smooth[:,0] = np.maximum(avg_smooth[:,0], 0)
wt_smooth[:,0] = np.maximum(wt_smooth[:,0], 0)

print(f"\nAverage contour: {len(avg_smooth)} pts")
print(f"  dx range: [{avg_smooth[:,0].min():.4f}, {avg_smooth[:,0].max():.4f}]")
print(f"  dy range: [{avg_smooth[:,1].min():.4f}, {avg_smooth[:,1].max():.4f}]")

# ═══════════════════════════════════════════════════════════
# STEP 4: Learn stroke patterns
# ═══════════════════════════════════════════════════════════

def analyze_strokes(data, name):
    """Extract stroke statistics by body region."""
    strokes = [np.array(s) for s in data["strokes"]]
    
    # Classify each stroke by its centroid y-position into body regions
    regions = {
        'head':      (0, 1),
        'neck_shoulder': (1, 2),
        'torso':     (2, 3),
        'hip':       (3, 4),
        'upper_leg': (4, 5),
        'lower_leg': (5, 6),
        'ankle_foot': (6, 8),
    }
    
    region_stats = {}
    for rname, (y_lo, y_hi) in regions.items():
        region_strokes = [s for s in strokes 
                         if y_lo <= np.mean(s[:,1]) < y_hi]
        if not region_strokes:
            region_stats[rname] = {'count': 0}
            continue
        
        # For each stroke, compute: centroid, extent, aspect ratio, curvature
        stats_list = []
        for s in region_strokes:
            cx, cy = s[:,0].mean(), s[:,1].mean()
            rx = (s[:,0].max() - s[:,0].min()) / 2
            ry = (s[:,1].max() - s[:,1].min()) / 2
            n_pts = len(s)
            
            # Is it roughly circular? (joint indicator)
            if rx > 0.01 and ry > 0.01:
                aspect = min(rx, ry) / max(rx, ry)
            else:
                aspect = 0
            
            # Is it roughly linear?
            if n_pts >= 3:
                # Fit line, measure residual
                t = np.linspace(0, 1, n_pts)
                dx_fit = np.polyfit(t, s[:,0], 1)
                dy_fit = np.polyfit(t, s[:,1], 1)
                x_pred = np.polyval(dx_fit, t)
                y_pred = np.polyval(dy_fit, t)
                residual = np.sqrt(((s[:,0]-x_pred)**2 + (s[:,1]-y_pred)**2).mean())
            else:
                residual = 0
            
            stats_list.append({
                'cx': cx, 'cy': cy, 'rx': rx, 'ry': ry,
                'n_pts': n_pts, 'aspect': aspect, 'linearity_residual': residual,
                'is_circular': aspect > 0.6 and residual > 0.01,
                'is_linear': residual < 0.01,
            })
        
        region_stats[rname] = {
            'count': len(region_strokes),
            'avg_cx': np.mean([s['cx'] for s in stats_list]),
            'avg_cy': np.mean([s['cy'] for s in stats_list]),
            'avg_rx': np.mean([s['rx'] for s in stats_list]),
            'avg_ry': np.mean([s['ry'] for s in stats_list]),
            'circular_count': sum(1 for s in stats_list if s['is_circular']),
            'linear_count': sum(1 for s in stats_list if s['is_linear']),
            'strokes': stats_list,
            'raw': region_strokes,
        }
    
    return region_stats

all_stats = {}
for name, data in [("moto", moto), ("anat", anat), ("hero", hero)]:
    all_stats[name] = analyze_strokes(data, name)

# Print summary
print("\nStroke patterns by region:")
print(f"{'Region':<16} {'moto':>8} {'anat':>8} {'hero':>8} {'avg':>8}")
for region in ['head', 'neck_shoulder', 'torso', 'hip', 'upper_leg', 'lower_leg', 'ankle_foot']:
    counts = [all_stats[n].get(region, {}).get('count', 0) for n in ['moto', 'anat', 'hero']]
    print(f"{region:<16} {counts[0]:>8} {counts[1]:>8} {counts[2]:>8} {np.mean(counts):>8.1f}")

# ═══════════════════════════════════════════════════════════
# STEP 5: Generate strokes from learned patterns
#   Use anatomy study strokes as the "template" since it has
#   the cleanest anatomical detail, then adapt placement
#   to match the new contour's proportions
# ═══════════════════════════════════════════════════════════

def transplant_strokes(source_contour, source_strokes, target_contour):
    """
    Transplant strokes from source to target by mapping their
    relative position within the silhouette.
    
    For each stroke point (dx, dy):
      1. Find the source contour width at that dy level
      2. Compute relative position: dx / source_width
      3. Apply same relative position to target contour width at that dy
    """
    src_c = np.array(source_contour)
    tgt_c = np.array(target_contour)
    
    # Build width-at-y lookup for both contours
    def width_at_y(contour, y_levels):
        """Max dx at each y level."""
        widths = np.zeros(len(y_levels))
        for i, y in enumerate(y_levels):
            mask = np.abs(contour[:,1] - y) < 0.1
            if mask.any():
                widths[i] = contour[mask, 0].max()
            else:
                # Extrapolate from nearest
                dists = np.abs(contour[:,1] - y)
                nearest = np.argmin(dists)
                widths[i] = contour[nearest, 0]
        return widths
    
    y_grid = np.arange(0, 8.5, 0.05)
    src_widths = width_at_y(src_c, y_grid)
    tgt_widths = width_at_y(tgt_c, y_grid)
    
    # Build interpolators
    src_w_interp = interp1d(y_grid, src_widths, bounds_error=False, fill_value='extrapolate')
    tgt_w_interp = interp1d(y_grid, tgt_widths, bounds_error=False, fill_value='extrapolate')
    
    transplanted = []
    for stroke in source_strokes:
        s = np.array(stroke)
        new_s = np.zeros_like(s)
        for j in range(len(s)):
            dy = s[j, 1]
            dx = s[j, 0]
            
            src_w = max(src_w_interp(dy), 0.01)
            tgt_w = max(tgt_w_interp(dy), 0.01)
            
            # Map dx proportionally
            relative_dx = dx / src_w
            new_s[j, 0] = relative_dx * tgt_w
            new_s[j, 1] = dy  # keep y position
        
        transplanted.append(new_s)
    
    return transplanted

# ═══════════════════════════════════════════════════════════
# STEP 6: Generate the new figure
# ═══════════════════════════════════════════════════════════

# Use weighted-average contour
new_contour = wt_smooth

# Transplant anatomy strokes onto the new contour
anat_strokes = [np.array(s) for s in anat["strokes"]]
new_strokes = transplant_strokes(
    anat["contour"], anat["strokes"], new_contour
)

# Also transplant a selection of moto strokes for variety
# (only the larger, more distinctive ones)
moto_strokes_raw = [np.array(s) for s in moto["strokes"]]
large_moto = [s for s in moto_strokes_raw if len(s) > 20 and np.mean(s[:,1]) > 4]
if large_moto:
    moto_transplanted = transplant_strokes(
        moto["contour"], [s.tolist() for s in large_moto[:10]], new_contour
    )
else:
    moto_transplanted = []

print(f"\nGenerated contour: {len(new_contour)} pts")
print(f"Transplanted anatomy strokes: {len(new_strokes)}")
print(f"Transplanted moto strokes (bonus): {len(moto_transplanted)}")

# Combine strokes (anatomy base + some moto detail)
all_strokes = new_strokes  # keep it clean, just anatomy

# Build output
generated = {
    "contour": new_contour.tolist(),
    "strokes": [s.tolist() for s in all_strokes],
    "meta": {
        "contour_points": len(new_contour),
        "detail_strokes": len(all_strokes),
        "source": "data_driven_generation",
        "method": "weighted_average_contour + stroke_transplant",
        "weights": {"moto": 0.2, "anatomy": 0.6, "hero": 0.2},
    }
}

with open("/home/claude/generated_learned.json", "w") as f:
    json.dump(generated, f)
print("Saved generated_learned.json")

# ═══════════════════════════════════════════════════════════
# BONUS: Generate a "heroic" variant (wider shoulders, 
#   narrower waist — interpolate toward hero proportions)
# ═══════════════════════════════════════════════════════════

heroic_contour = (
    0.1 * contours["moto"] + 
    0.3 * contours["anat"] + 
    0.6 * contours["hero"]
)
heroic_contour = np.column_stack([
    uniform_filter1d(heroic_contour[:,0], 5, mode='nearest'),
    uniform_filter1d(heroic_contour[:,1], 5, mode='nearest'),
])
heroic_contour[:,0] = np.maximum(heroic_contour[:,0], 0)

heroic_strokes = transplant_strokes(
    anat["contour"], anat["strokes"], heroic_contour
)

heroic = {
    "contour": heroic_contour.tolist(),
    "strokes": [s.tolist() for s in heroic_strokes],
    "meta": {
        "contour_points": len(heroic_contour),
        "detail_strokes": len(heroic_strokes),
        "source": "data_driven_heroic_variant",
        "method": "hero_weighted_contour + stroke_transplant",
        "weights": {"moto": 0.1, "anatomy": 0.3, "hero": 0.6},
    }
}

with open("/home/claude/generated_heroic.json", "w") as f:
    json.dump(heroic, f)
print("Saved generated_heroic.json")

