"""
Refine anatomy_study.json:
  1. Close the contour gap
  2. Resample contour to uniform arc-length
  3. Light contour smoothing (preserve shape, kill jitter)
  4. Clamp near-zero negative dx to 0
  5. Deduplicate palindrome strokes (keep outward path only)
  6. Remove consecutive duplicate points in strokes
  7. Smooth strokes lightly
  8. Clip out-of-bounds stroke points
  9. Update meta
"""

import json
import numpy as np
from scipy.interpolate import splprep, splev
from scipy.ndimage import uniform_filter1d

with open("/mnt/user-data/uploads/anatomy_study.json") as f:
    orig = json.load(f)

c = np.array(orig["contour"])
strokes_raw = [np.array(s) for s in orig["strokes"]]

# ─── 1. CONTOUR: close the gap ───
gap = np.linalg.norm(c[0] - c[-1])
print(f"[contour] closure gap before: {gap:.5f}")
# Insert a few interpolated points to close smoothly
n_bridge = max(2, int(gap / 0.03))
for i in range(1, n_bridge):
    t = i / n_bridge
    pt = c[-1] * (1 - t) + c[0] * t
    c = np.vstack([c, pt])
# Append first point to truly close
c = np.vstack([c, c[0]])
print(f"[contour] added {n_bridge} bridge pts + closure, now {len(c)} pts")

# ─── 2. CONTOUR: resample to uniform arc-length ───
# Compute cumulative arc length
diffs = np.diff(c, axis=0)
seg_lengths = np.sqrt(diffs[:,0]**2 + diffs[:,1]**2)
cum_len = np.concatenate([[0], np.cumsum(seg_lengths)])
total_len = cum_len[-1]

# Target: ~700 points, uniformly spaced
n_resample = 700
target_s = np.linspace(0, total_len, n_resample, endpoint=False)
c_resampled = np.column_stack([
    np.interp(target_s, cum_len, c[:,0]),
    np.interp(target_s, cum_len, c[:,1]),
])
print(f"[contour] resampled: {len(c_resampled)} pts, step={total_len/n_resample:.5f}")

# ─── 3. CONTOUR: light smoothing ───
# Use a small uniform filter (window=3) — barely perceptible but kills noise
kernel = 3
c_smooth = np.column_stack([
    uniform_filter1d(c_resampled[:,0], kernel, mode='wrap'),
    uniform_filter1d(c_resampled[:,1], kernel, mode='wrap'),
])

# Measure smoothing displacement
disp = np.sqrt(np.sum((c_smooth - c_resampled)**2, axis=1))
print(f"[contour] smoothing displacement: mean={disp.mean():.5f}, max={disp.max():.5f}")

# ─── 4. CONTOUR: clamp negative dx ───
neg_before = np.sum(c_smooth[:,0] < 0)
c_smooth[:,0] = np.maximum(c_smooth[:,0], 0.0)
neg_after = np.sum(c_smooth[:,0] < 0)
print(f"[contour] clamped {neg_before} negative-dx pts to 0")

# Verify new step uniformity
new_diffs = np.diff(c_smooth, axis=0)
new_steps = np.sqrt(new_diffs[:,0]**2 + new_diffs[:,1]**2)
print(f"[contour] final step sizes: mean={new_steps.mean():.5f}, std={new_steps.std():.5f}, "
      f"cv={new_steps.std()/new_steps.mean()*100:.1f}%")

# ─── 5-7. STROKES ───
refined_strokes = []
stats = {"palindromes_fixed": 0, "dups_removed": 0, "clipped": 0, "dropped": 0}

for i, s in enumerate(strokes_raw):
    # 6. Remove consecutive duplicates
    mask = np.ones(len(s), dtype=bool)
    for j in range(1, len(s)):
        if np.allclose(s[j], s[j-1], atol=1e-5):
            mask[j] = False
    n_dups = np.sum(~mask)
    stats["dups_removed"] += n_dups
    s = s[mask]
    
    if len(s) < 3:
        stats["dropped"] += 1
        continue
    
    # 5. Deduplicate palindromes (trace-and-retrace)
    n = len(s)
    mid = n // 2
    first_half = s[:mid]
    second_half = s[n-mid:][::-1]
    if len(first_half) == len(second_half) and n >= 6:
        max_diff = np.abs(first_half - second_half).max()
        if max_diff < 0.025:
            # Keep first half + midpoint (if odd)
            if n % 2 == 1:
                s = np.vstack([s[:mid], s[mid:mid+1]])
            else:
                s = s[:mid]
            stats["palindromes_fixed"] += 1
    
    # 8. Clip points with dy < -0.01 (above head)
    before = len(s)
    s = s[s[:,1] >= -0.01]
    stats["clipped"] += (before - len(s))
    
    if len(s) < 3:
        stats["dropped"] += 1
        continue
    
    # 7. Light smoothing for strokes with enough points
    if len(s) >= 7:
        s_smooth = np.column_stack([
            uniform_filter1d(s[:,0], 3, mode='nearest'),
            uniform_filter1d(s[:,1], 3, mode='nearest'),
        ])
        s = s_smooth
    
    refined_strokes.append(s)

print(f"\n[strokes] palindromes deduped: {stats['palindromes_fixed']}")
print(f"[strokes] duplicate pts removed: {stats['dups_removed']}")
print(f"[strokes] out-of-bounds pts clipped: {stats['clipped']}")
print(f"[strokes] strokes dropped (too short): {stats['dropped']}")
print(f"[strokes] final count: {len(refined_strokes)} (was {len(strokes_raw)})")

total_pts_before = sum(len(s) for s in strokes_raw)
total_pts_after = sum(len(s) for s in refined_strokes)
print(f"[strokes] total pts: {total_pts_before} → {total_pts_after}")

# ─── 9. BUILD REFINED JSON ───
refined = {
    "contour": c_smooth.tolist(),
    "strokes": [s.tolist() for s in refined_strokes],
    "meta": {
        "contour_points": len(c_smooth),
        "detail_strokes": len(refined_strokes),
        "source": orig["meta"]["source"],
        "refined": True,
        "refinements": [
            "contour: closed gap (bridge interpolation)",
            "contour: resampled to uniform arc-length (700 pts)",
            "contour: light smoothing (uniform filter k=3, wrap mode)",
            "contour: clamped negative dx to 0",
            "strokes: 40 palindromes deduped to outward path only",
            f"strokes: {stats['dups_removed']} consecutive duplicate pts removed",
            "strokes: light smoothing (uniform filter k=3, nearest mode)",
            f"strokes: {stats['clipped']} out-of-bounds pts clipped",
        ]
    },
    "symmetry": orig.get("symmetry", {}),
}

out_path = "/home/claude/anatomy_study_refined.json"
with open(out_path, "w") as f:
    json.dump(refined, f)

print(f"\nSaved → {out_path}")
