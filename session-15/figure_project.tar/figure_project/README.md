# Figure Contour Extraction & Generation Toolkit

## Structure

```
scripts/          — Python tools (pipeline)
data/extracted/   — JSON contour+stroke data from images/text
data/generated/   — JSON from data-driven generation
data/refined/     — Cleaned/refined versions of extracted data
renders/          — PNG renders from draw_figure.py
```

## Scripts

| Script | Purpose |
|---|---|
| `convert.py` | Universal `.txt` → `.json` converter (both section-header formats) |
| `draw_figure.py` | Matplotlib renderer: JSON → mirrored PNG |
| `refine.py` | Close contour gaps, resample, dedup palindromes, smooth |
| `analyze.py` | Cross-dataset comparison (widths, strokes, proportions) |
| `learn_and_generate.py` | Data-driven generator: contour averaging + stroke transplant |
| `extract_scanline.py` | Image → JSON via scan-line silhouette + skeleton strokes |
| `extract_with_guide_removal.py` | Same + horizontal/vertical guide line removal |
| `batch_extract.py` | Batch wrapper for extraction |

## Data Format (JSON)

```json
{
  "contour": [[dx, dy], ...],   // right-half silhouette, head-unit coords
  "strokes": [[[dx, dy], ...], ...],  // detail curves, right-half only
  "meta": { "contour_points": N, "detail_strokes": M, "source": "..." }
}
```

- `dx` = distance from midline (head-units)
- `dy` = distance from crown (head-units, 0=top, 8=feet)
- Renderer mirrors both contour and strokes to create full symmetric figure

## Datasets

| File | Source | Contour | Strokes | Type |
|---|---|---|---|---|
| `moto_rider.json` | text extraction | 734 | 292 | Male, motorcycle gear |
| `anatomy_study.json` | direct JSON | 699 | 81 | Male, nude anatomy |
| `hero_figure.json` | text extraction | 640 | 118 | Male, sentai armor |
| `biker_girl.json` | text extraction | 639 | 179 | Female, leather jacket |
| `warrior_front.json` | image extraction | 700 | 173 | Male, barbarian armor (front) |
| `warrior_back.json` | image extraction | 700 | 160 | Male, barbarian armor (back) |
| `heroine_front.json` | image extraction | 700 | 163 | Female, bodysuit (front) |
| `heroine_back.json` | image extraction | 700 | 120 | Female, bodysuit (back) |
| `generated_learned.json` | data-driven | 800 | 81 | Anatomy-weighted average |
| `generated_heroic.json` | data-driven | 800 | 81 | Hero-weighted variant |

## Usage

```bash
# Convert text to JSON
python scripts/convert.py input.txt output.json

# Render JSON to PNG
python scripts/draw_figure.py data/extracted/moto_rider.json output.png

# Extract from image
python scripts/extract_with_guide_removal.py  # (edit paths inside)

# Generate new figure from learned patterns
python scripts/learn_and_generate.py  # (edit source paths inside)
```
